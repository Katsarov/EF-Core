﻿namespace TeisterMask.DataProcessor
{
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Castle.Components.DictionaryAdapter;
    using Castle.DynamicProxy.Generators;
    using Newtonsoft.Json;
    using TeisterMask.DataProcessor.ExportDto;

    namespace TeisterMask.DataProcessor
    {
        using System;
        using Data;
        using Formatting = Newtonsoft.Json.Formatting;

        public class Serializer
        {
            public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
            {
                StringBuilder sb = new StringBuilder();

                XmlSerializer xmlSerializer =
                    new XmlSerializer(typeof(ProjectExportDto[]), new XmlRootAttribute("Projects"));

                var namespaces = new XmlSerializerNamespaces();
                namespaces.Add(string.Empty, string.Empty);

                using (StringWriter stringWriter = new StringWriter(sb))
                {
                    ProjectExportDto[] projects = context.Projects
                        .Where(p => p.Tasks.Count > 0)
                        .Select(p => new ProjectExportDto()
                        {
                            HasEndDate = p.DueDate.HasValue ? "Yes" : "No",
                            Name = p.Name,
                            TasksCount = p.Tasks.Count,
                            Tasks = p.Tasks.Select(t => new TaskExportDto()
                            {
                                Name = t.Name,
                                Label = t.LabelType.ToString()
                            })
                                .OrderBy(t => t.Name)
                                .ToArray()
                        })
                        .OrderByDescending(p => p.TasksCount)
                        .ThenBy(p => p.Name)
                        .ToArray();

                    xmlSerializer.Serialize(stringWriter, projects, namespaces);
                }

                return sb.ToString().TrimEnd();

            }

            public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
            {
                var employees = context.Employees
                    .Where(e => e.EmployeesTasks.Any(et => et.Task.OpenDate >= date))
                    .Select(e => new
                    {
                        Username = e.Username,
                        Tasks = e.EmployeesTasks
                            .Where(et => et.Task.OpenDate >= date)
                            .OrderByDescending(et => et.Task.DueDate)
                            .ThenBy(et => et.Task.Name)
                            .Select(et => new
                            {
                                TaskName = et.Task.Name,
                                OpenDate = et.Task.OpenDate.ToString("d", CultureInfo.InvariantCulture),
                                DueDate = et.Task.DueDate.ToString("d", CultureInfo.InvariantCulture),
                                LabelType = et.Task.LabelType.ToString(),
                                ExecutionType = et.Task.ExecutionType.ToString()
                            })
                            .ToArray()

                    })
                    .OrderByDescending(e => e.Tasks.Length)
                    .ThenBy(e => e.Username)
                    .Take(10)
                    .ToArray();

                string json = JsonConvert.SerializeObject(employees, Formatting.Indented);

                return json;

            }
        }
    }






    //using System;
    //using System.Collections.Generic;

    //using System.ComponentModel.DataAnnotations;
    //using System.Globalization;
    //using System.IO;
    //using System.Linq;
    //using System.Text;
    //using System.Xml.Serialization;
    //using Data;
    //using Newtonsoft.Json;
    //using TeisterMask.Data.Models;
    //using TeisterMask.Data.Models.Enums;
    //using TeisterMask.DataProcessor.ImportDto;
    //using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    //public class Deserializer
    //{
    //    public static string ImportProjects(TeisterMaskContext context, string xmlString)
    //    {
    //        var sb = new StringBuilder();

    //        var serializer = new XmlSerializer(typeof(List<ImportProjectDto>), new XmlRootAttribute("Projects"));

    //        var reader = new StringReader(xmlString);

    //        var projectsToAdd = new List<Project>();

    //        using (reader)
    //        {

    //            var projectDtos = (List<ImportProjectDto>)serializer.Deserialize(reader);

    //            foreach (var project in projectDtos)
    //            {
    //                if (!IsValid(project))
    //                {
    //                    sb.AppendLine("Invalid data!");
    //                    continue;
    //                }

    //                var isOpenDateValid = DateTime.TryParseExact(project.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime projectOpenDate);

    //                if (!isOpenDateValid)
    //                {
    //                    sb.AppendLine("Invalid data!");
    //                    continue;
    //                }

    //                DateTime? projectDueDate = null;

    //                if (!string.IsNullOrEmpty(project.DueDate))
    //                {
    //                    var isProjectDueDateValid = DateTime.TryParseExact(project.DueDate, "dd/MM/yyyy",
    //                        CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime projectDueDateValue);

    //                    if (!isProjectDueDateValid)
    //                    {
    //                        sb.AppendLine("Invalid data!");
    //                        continue;
    //                    }

    //                    projectDueDate = projectDueDateValue;
    //                }

    //                var projectToAdd = new Project()
    //                {
    //                    Name = project.Name,
    //                    OpenDate = projectOpenDate,
    //                    DueDate = projectDueDate
    //                };

    //                foreach (var task in project.Tasks)
    //                {
    //                    if (!IsValid(task))
    //                    {
    //                        sb.AppendLine("Invalid data!");

    //                        continue;
    //                    }

    //                    bool isTaskOpenDateValid = DateTime.TryParseExact(task.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture,
    //                        DateTimeStyles.None, out DateTime taskOpenDate);

    //                    if (!isTaskOpenDateValid)
    //                    {
    //                        sb.AppendLine("Invalid data!");

    //                        continue;
    //                    }

    //                    if (taskOpenDate < projectToAdd.OpenDate)
    //                    {
    //                        sb.AppendLine("Invalid data!");

    //                        continue;
    //                    }

    //                    var isTaskDueDateValid = DateTime.TryParseExact(task.DueDate, "dd/MM/yyyy",
    //                        CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime taskDueDate);

    //                    if (!isTaskDueDateValid)
    //                    {
    //                        sb.AppendLine("Invalid data!");

    //                        continue;
    //                    }

    //                    if (projectDueDate.HasValue)
    //                    {
    //                        if (taskDueDate > projectToAdd.DueDate)
    //                        {
    //                            sb.AppendLine("Invalid data!");

    //                            continue;
    //                        }
    //                    }

    //                    var taskToAdd = new Task()
    //                    {
    //                        Name = task.Name,
    //                        OpenDate = taskOpenDate,
    //                        DueDate = taskDueDate,
    //                        ExecutionType = (ExecutionType)task.ExecutionType,
    //                        LabelType = (LabelType)task.LabelType
    //                    };

    //                    projectToAdd.Tasks.Add(taskToAdd);
    //                }

    //                projectsToAdd.Add(projectToAdd);

    //                sb.AppendLine($"Successfully imported project - {projectToAdd.Name} with {projectToAdd.Tasks.Count} tasks.");
    //            }

    //            context.Projects.AddRange(projectsToAdd);

    //            context.SaveChanges();

    //            return sb.ToString().Trim();
    //        }
    //    }

    //    public static string ImportEmployees(TeisterMaskContext context, string jsonString)
    //    {
    //        var sb = new StringBuilder();

    //        var employeeDtos = JsonConvert.DeserializeObject<List<ImportEmployeeDto>>(jsonString);

    //        var employeesToAdd = new List<Employee>();

    //        foreach (var employee in employeeDtos)
    //        {
    //            if (!IsValid(employee))
    //            {
    //                sb.AppendLine("Invalid data!");
    //                continue;
    //            }

    //            if (employee.Username.Any(x => !char.IsLetterOrDigit(x)))
    //            {
    //                sb.AppendLine("Invalid data!");
    //            }

    //            var employeeToAdd = new Employee()
    //            {
    //                Username = employee.Username,
    //                Email = employee.Email,
    //                Phone = employee.Phone
    //            };

    //            foreach (var taskId in employee.Tasks.Distinct())
    //            {
    //                if (context.Tasks.All(x => x.Id != taskId))
    //                {
    //                    sb.AppendLine("Invalid data!");
    //                    continue;
    //                }

    //                var taskToAdd = context.Tasks.FirstOrDefault(x => x.Id == taskId);

    //                var employeeTask = new EmployeeTask()
    //                {
    //                    Employee = employeeToAdd,
    //                    Task = taskToAdd
    //                };

    //                employeeToAdd.EmployeesTasks.Add(employeeTask);
    //            }

    //            employeesToAdd.Add(employeeToAdd);

    //            sb.AppendLine($"Successfully imported employee - {employeeToAdd.Username} with {employeeToAdd.EmployeesTasks.Count} tasks.");
    //        }

    //        context.Employees.AddRange(employeesToAdd);

    //        context.SaveChanges();

    //        return sb.ToString().Trim();
    //    }

    //    private static bool IsValid(object dto)
    //    {
    //        var validationContext = new ValidationContext(dto);
    //        var validationResult = new List<ValidationResult>();

    //        return Validator.TryValidateObject(dto, validationContext, validationResult, true);
    //    }
    //}
}