﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;

    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using TeisterMask.Data.Models;
    using TeisterMask.Data.Models.Enums;
    using TeisterMask.DataProcessor.ImportDto;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public class Deserializer
    {
        public static string ImportProjects(TeisterMaskContext context, string xmlString)
        {
            var sb = new StringBuilder();

            var serializer = new XmlSerializer(typeof(List<ImportProjectDto>), new XmlRootAttribute("Projects"));

            var reader = new StringReader(xmlString);

            var projectsToAdd = new List<Project>();

                var projectDtos = (List<ImportProjectDto>)serializer.Deserialize(reader);

                foreach (var project in projectDtos)
                {
                    if (!IsValid(project))
                    {
                        sb.AppendLine("Invalid data!");
                        continue;
                    }

                    var isOpenDateValid = DateTime.TryParseExact(project.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime projectOpenDate);

                    if (!isOpenDateValid)
                    {
                        sb.AppendLine("Invalid data!");
                        continue;
                    }

                    DateTime? projectDueDate = null;

                    if (!string.IsNullOrEmpty(project.DueDate))
                    {
                        var isProjectDueDateValid = DateTime.TryParseExact(project.DueDate, "dd/MM/yyyy",
                            CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime projectDueDateValue);

                        if (!isProjectDueDateValid)
                        {
                            sb.AppendLine("Invalid data!");
                            continue;
                        }

                        projectDueDate = projectDueDateValue;
                    }

                    var projectToAdd = new Project()
                    {
                        Name = project.Name,
                        OpenDate = projectOpenDate,
                        DueDate = projectDueDate
                    };

                    foreach (var task in project.Tasks)
                    {
                        if (!IsValid(task))
                        {
                            sb.AppendLine("Invalid data!");

                            continue;
                        }

                        bool isTaskOpenDateValid = DateTime.TryParseExact(task.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture,
                            DateTimeStyles.None, out DateTime taskOpenDate);

                        if (!isTaskOpenDateValid)
                        {
                            sb.AppendLine("Invalid data!");

                            continue;
                        }

                        if (taskOpenDate < projectToAdd.OpenDate)
                        {
                            sb.AppendLine("Invalid data!");

                            continue;
                        }

                        var isTaskDueDateValid = DateTime.TryParseExact(task.DueDate, "dd/MM/yyyy",
                            CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime taskDueDate);

                        if (!isTaskDueDateValid)
                        {
                            sb.AppendLine("Invalid data!");

                            continue;
                        }

                        if (projectDueDate.HasValue)
                        {
                            if (taskDueDate > projectToAdd.DueDate)
                            {
                                sb.AppendLine("Invalid data!");

                                continue;
                            }
                        }

                        var taskToAdd = new Task()
                        {
                            Name = task.Name,
                            OpenDate = taskOpenDate,
                            DueDate = taskDueDate,
                            ExecutionType = (ExecutionType)task.ExecutionType,
                            LabelType = (LabelType)task.LabelType
                        };

                        projectToAdd.Tasks.Add(taskToAdd);
                    }

                    projectsToAdd.Add(projectToAdd);

                    sb.AppendLine($"Successfully imported project - {projectToAdd.Name} with {projectToAdd.Tasks.Count} tasks.");
                }

                context.Projects.AddRange(projectsToAdd);

                context.SaveChanges();

                return sb.ToString().Trim();
            //}
        }

        public static string ImportEmployees(TeisterMaskContext context, string jsonString)
        {
            throw new NotImplementedException();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}